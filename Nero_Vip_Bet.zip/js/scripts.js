
document.addEventListener("DOMContentLoaded", () => {
    console.log("Nero Vip Bet site is ready!");
});
